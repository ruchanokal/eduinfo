package com.edu.info.model

class Student(val username : String, val userUid : String, val info : StudentInfo) {
}