package com.edu.info.model

class StudentInfo(val math : String?,
                  val phy : String?,
                  val che: String?,
                  val eco: String?,
                  val lit : String?,
                  val geo : String?,
                  val soc : String?,
                  val absence : String? )